const domainName = "helpforallusa.com";

const G2DisplayName = "Peak Plans LLC. - G2 Certification";
const G2Link =
  "https://www.g2llc.com/approved-health-insurance-provider/?pdb=2314";

const addLeadId = true;

const qualifyNumber = "8555792872";
const overflowNumber = "8556714382";

const overflowRingbaCampaignID = "CA7f1be56c7e6f4e229cb806b4c76add9a";
const normalRingbaCampaignID = "CA0457ccda8864417991b332abbcc7951c";

const googleAccountConversionTagID = "";
const googleConversionTagEventSentTo = "";
const googleConversionTagValue = 1.0;

const qualifyDebtNumber = "";
const normalRingbaDebtCampaignID = "CA3d44f20051764969b1181db77bfbfd7b";
const overflowDebtNumber = "";
const overflowRingbaDebtCampaignID = "CA6ba3ea908b3149afb82e3a3904113a08";

const qualifySpDebtNumber = "";
const normalRingbaSpDebtCampaignID = "CA4d1d63d6f1054fb5be8f69dc661fc681";
const overflowSpDebtNumber = "";
const overflowRingbaSpDebtCampaignID = "CAfcac3e7c53f94634b91cf2e55a6166f4";